﻿
#nullable disable
using System;


using System.Windows.Forms;
using FlappyBird3Layer.Business;
using System.Media;

namespace FlappyBird3Layer.Presentation
{
    public partial class FormGame : Form
    {
        private const int VW = 900;
        private const int VH = 600;

        private GameManager _game;
        private System.Windows.Forms.Timer _timer;
        private int _prevScore;
        private bool _prevGameOver;
        public FormGame()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.DoubleBuffered = true;

            _game = new GameManager(this.ClientSize.Width, this.ClientSize.Height);
            _prevScore = _game.Score;
            _prevGameOver = _game.IsGameOver;
            _timer = new System.Windows.Forms.Timer();
            _timer.Interval = 20;
            _timer.Tick += Timer_Tick;
            _timer.Start();

        }


        // >>> THÊM HÀM NÀY <<<
        private void FormGame_Load(object sender, EventArgs e)
        {
            // Nếu cần khởi tạo gì thêm thì viết ở đây,
            // không thì cứ để trống cũng được.
        }
        // >>> HẾT PHẦN THÊM <<<

        private void Timer_Tick(object sender, EventArgs e)
        {
            _game.Update();
            if (_game.Score > _prevScore)
            {
                SystemSounds.Exclamation.Play();
                _prevScore = _game.Score;
            }

            if (!_prevGameOver && _game.IsGameOver)
            {
                SystemSounds.Hand.Play();
                _prevGameOver = true;
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            float sx = (float)ClientSize.Width / VW;
            float sy = (float)ClientSize.Height / VH;
            float s = Math.Min(sx, sy);

            float drawW = VW * s;
            float drawH = VH * s;

            float ox = (ClientSize.Width - drawW) / 2f;
            float oy = (ClientSize.Height - drawH) / 2f;

            e.Graphics.TranslateTransform(ox, oy);
            e.Graphics.ScaleTransform(s, s);

            _game.Draw(e.Graphics);

            e.Graphics.ResetTransform();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

            if (e.KeyCode == Keys.Space)
            {
                if (_game.IsGameOver)
                {
                    _game.Reset();
                    _prevScore = _game.Score;
                    _prevGameOver = _game.IsGameOver;
                }
                else
                {
                    SystemSounds.Asterisk.Play();
                    _game.BirdJump();
                }
            }
        }
    }
}