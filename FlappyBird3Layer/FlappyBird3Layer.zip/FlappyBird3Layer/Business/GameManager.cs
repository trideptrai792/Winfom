﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Drawing;

namespace FlappyBird3Layer.Business
{
    public class GameManager
    {
        public List<PowerUp> PowerUps { get; private set; } = new List<PowerUp>();

        private bool _hasShield;
        private int _slowTicks;
        private int _drunkTicks;
        private int _drunkPhase;
        private int _magnetTicks;
        private double _speedMul = 1.0;

        private int _puCooldownPipes = 0;

        private const int BirdSize = 30;
        private const int PipeStartOffset = 80;

        public Bird Bird { get; private set; }
        public List<Pipe> Pipes { get; private set; } = new List<Pipe>();
        public int Score { get; private set; }
        public bool IsGameOver { get; private set; }
        public Image BirdImage { get; set; }

        private readonly int _formWidth;
        private readonly int _formHeight;
        private readonly Random _rand = new Random();

        private const int GroundHeight = 80;
        private const int PipeWidth = 60;


        public GameManager(int formWidth, int formHeight)
        {
            _formWidth = formWidth;
            _formHeight = formHeight;
            Reset();
        }

        public void Reset()
        {
            Score = 0;
            IsGameOver = false;
            Bird = new Bird(100, _formHeight / 2);
            Pipes.Clear();
            SpawnPipe();
            PowerUps.Clear();
            _hasShield = false;
            _slowTicks = 0;
            _magnetTicks = 0;
            _speedMul = 1.0;
            _drunkTicks = 0;
            _drunkPhase = 0;
            _puCooldownPipes = 0;

        }
      
        public void BirdJump()
        {
            if (!IsGameOver) Bird.Jump();
        }

        public void Update()
        {
            if (IsGameOver) return;

            Bird.Update();
            if (_slowTicks > 0) _slowTicks--;
            if (_magnetTicks > 0) _magnetTicks--;
            int baseSpeed = GetSpeed();
            int curSpeed = (_slowTicks > 0) ? (int)Math.Round(baseSpeed * 0.5) : baseSpeed;
            if (curSpeed < 1) curSpeed = 1;
            if (_slowTicks > 0) _slowTicks--;
            if (_magnetTicks > 0) _magnetTicks--;
            if (_drunkTicks > 0) { _drunkTicks--; _drunkPhase++; }
            int bcx = Bird.X + BirdSize / 2;
            int bcy = Bird.Y + BirdSize / 2;
            for (int i = 0; i < Pipes.Count; i++)
            {
                Pipes[i].Speed = curSpeed;
                Pipes[i].Update();
            }
            for (int i = 0; i < PowerUps.Count; i++)
            {
                PowerUps[i].X -= curSpeed;
            }

            for (int i = PowerUps.Count - 1; i >= 0; i--)
            {
                if (PowerUps[i].X < -120)
                    PowerUps.RemoveAt(i);
            }



            if (Pipes.Count > 0)
            {
                var last = Pipes[Pipes.Count - 1];
                int spawnDist = GetSpawnDistance();
                if (last.X < _formWidth - spawnDist)
                    SpawnPipe();
            }

            for (int i = Pipes.Count - 1; i >= 0; i--)
            {
                if (Pipes[i].X < -PipeWidth - 80)
                    Pipes.RemoveAt(i);
            }

            for (int i = 0; i < Pipes.Count; i++)
            {
                var p = Pipes[i];
                if (!p.Passed && (p.X + PipeWidth) < Bird.X)
                {
                    p.Passed = true;
                    Score++;
                }
            }
            for (int i = PowerUps.Count - 1; i >= 0; i--)
            {
                var pu = PowerUps[i];
                int dx = pu.X - bcx;
                int dy = pu.Y - bcy;

                int r = pu.Radius + BirdSize / 2;
                if (dx * dx + dy * dy <= r * r)
                {
                    if (pu.Type == PowerUpType.Shield) _hasShield = true;
                    else if (pu.Type == PowerUpType.SlowTime) _slowTicks = 150;   // 3s (20ms/tick)
                    else if (pu.Type == PowerUpType.Magnet) _magnetTicks = 200;    // 4s
                    else if (pu.Type == PowerUpType.Drunk) _drunkTicks = 220;
                    // ~4.4s (20ms/tick)
                    PowerUps.RemoveAt(i);
                }
            }
            CheckCollision();
        }
        private void SpawnPipe()
        {
            int gapH = GetGapHeight();
            int speed = GetSpeed();

            int topMargin = 60;
            int bottomMargin = GroundHeight + 60;

            int minY = topMargin + gapH / 2;
            int maxY = _formHeight - bottomMargin - gapH / 2;
            if (maxY <= minY) maxY = minY + 1;

            int gapY = _rand.Next(minY, maxY);
            int startX = _formWidth + PipeStartOffset;

            Pipes.Add(new Pipe(startX, gapY, gapH, speed));

            if (_puCooldownPipes > 0) _puCooldownPipes--;
            if (_puCooldownPipes == 0 && _rand.NextDouble() < 0.25)
            // 25%
            {
              int t = _rand.Next(0, 4);
PowerUpType type =
    (t == 0) ? PowerUpType.Shield :
    (t == 1) ? PowerUpType.SlowTime :
    (t == 2) ? PowerUpType.Magnet :
               PowerUpType.Drunk;
            }
        }


        private int GetLevel()
        {
            return Score / 5;
        }

        private int GetSpeed()
        {
            int lv = Score / 5;
            int speed = 3 + lv;
            if (speed > 10) speed = 10;
            return speed;
        }

        private int GetGapHeight()
        {
            int lv = Score / 5;
            int gap = 170 - lv * 10;
            if (gap < 95) gap = 95;
            return gap;
        }

        private int GetSpawnDistance()
        {
            int lv = Score / 5;
            int dist = 290 - lv * 12;
            if (dist < 220) dist = 220;
            return dist;
        }

        private void CheckCollision()
        {
            if (Bird.Y < 0 || Bird.Y > _formHeight - GroundHeight - 30)
            {
                IsGameOver = true;
                return;
            }

            for (int i = 0; i < Pipes.Count; i++)
            {
                var p = Pipes[i];

                bool collideX = Bird.X + 30 > p.X && Bird.X < p.X + PipeWidth;
                if (!collideX) continue;

                int topPipeBottom = p.GapY - p.GapHeight / 2;
                int bottomPipeTop = p.GapY + p.GapHeight / 2;

                bool hitTop = Bird.Y < topPipeBottom;
                bool hitBottom = Bird.Y + 30 > bottomPipeTop;

                if (hitTop || hitBottom)
                {
                    IsGameOver = true;
                    return;
                }
            }
        }

        public void Draw(Graphics g)
        {
            g.Clear(Color.SkyBlue);
            int camX = 0, camY = 0;
            if (_drunkTicks > 0)
            {
                camX = (_drunkPhase % 3) - 1;                 // -1,0,1
                camY = ((_drunkPhase / 2) % 3) - 1;           // -1,0,1
            }
            g.TranslateTransform(camX, camY);

            using (Brush groundBrush = new SolidBrush(Color.ForestGreen))
            {
                g.FillRectangle(groundBrush, 0, _formHeight - GroundHeight, _formWidth, GroundHeight);
            }

            using (Brush pipeBrush = new SolidBrush(Color.ForestGreen))
            {
                for (int i = 0; i < Pipes.Count; i++)
                {
                    var p = Pipes[i];

                    int topPipeBottom = p.GapY - p.GapHeight / 2;
                    int bottomPipeTop = p.GapY + p.GapHeight / 2;

                    g.FillRectangle(pipeBrush, p.X, 0, PipeWidth, topPipeBottom);
                    g.FillRectangle(pipeBrush, p.X, bottomPipeTop, PipeWidth, _formHeight - GroundHeight - bottomPipeTop);
                }
            }
            for (int i = 0; i < PowerUps.Count; i++)
            {
                var pu = PowerUps[i];

                Brush br = Brushes.Gold;
                string txt = "S";
                if (pu.Type == PowerUpType.SlowTime) { br = Brushes.LightBlue; txt = "T"; }
                if (pu.Type == PowerUpType.Magnet) { br = Brushes.Violet; txt = "M"; }

                g.FillEllipse(br, pu.X - pu.Radius, pu.Y - pu.Radius, pu.Radius * 2, pu.Radius * 2);
                g.DrawEllipse(Pens.Black, pu.X - pu.Radius, pu.Y - pu.Radius, pu.Radius * 2, pu.Radius * 2);

                using (Font f = new Font("Segoe UI", 10, FontStyle.Bold))
                    g.DrawString(txt, f, Brushes.Black, pu.X - 6, pu.Y - 8);
            }
            Bird.Draw(g);
            g.ResetTransform();
            using (Brush textBrush = new SolidBrush(Color.Black))
            using (Font font = new Font("Segoe UI", 16, FontStyle.Bold))
            {
                g.DrawString($"Score: {Score}", font, textBrush, 10, 10);

                if (IsGameOver)
                    g.DrawString("Game Over - nhấn Space để chơi lại", font, textBrush, 80, _formHeight / 2);
            }
        }
    }
}
